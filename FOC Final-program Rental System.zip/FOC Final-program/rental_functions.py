import datetime
import display_functions
import file_operations

# Function to generate and save rent invoice
def generate_and_save_rent_invoice(customer_name, rented_items, total_rental_amount):
    invoice = f"===== Rent Invoice for {customer_name} =====\n"

    for item in rented_items:
        equipment = item["equipment"]
        quantity = item["quantity"]
        rental_amount = item["rental_amount"]
        invoice += f"Equipment: {equipment['name']} ({equipment['brand']})\nQuantity: {quantity}\nRental Amount: ${rental_amount:.2f}\n\n"

    invoice += f"Total Rental Amount: ${total_rental_amount:.2f}\n"

    invoice_filename = f"{customer_name}_rent_invoice.txt"

    with open(invoice_filename, "w") as file:
        file.write(invoice)

    print(f"Rent Invoice saved as '{invoice_filename}'")

# Function to rent equipment
def rent_equipment(equipment_data):
    try:
        customer_name = input("Enter customer name: ").strip()
        total_rental_amount = 0  # Initialize total rental amount
        rented_items = []  # To store rented items and quantities

        while True:
            display_functions.display_available_equipment(equipment_data)  # Displaying available equipment
            equipment_index = int(input("Enter the equipment number to rent: ")) - 1

            if 0 <= equipment_index < len(equipment_data):
                equipment = equipment_data[equipment_index]
                rental_quantity = int(input(f"Enter rental quantity for {equipment['name']}: "))
                if equipment["quantity"] >= rental_quantity > 0:
                    equipment_data[equipment_index]["quantity"] -= rental_quantity
                    rental_amount = equipment["price"] * rental_quantity
                    total_rental_amount += rental_amount  # Update total rental amount
                    rented_items.append({"equipment": equipment, "quantity": rental_quantity, "rental_amount": rental_amount})
                    print(f"Successfully rented {rental_quantity} units of {equipment['name']} to {customer_name}.")
                else:
                    print("Equipment is not available for rent, quantity is insufficient, or quantity is invalid. Try again.")
            else:
                print("Invalid equipment number.")

            another_rent = input("Do you want to rent another item? (yes/no): ").lower()
            if another_rent != "yes":
                break

        if rented_items:
            print(f"Total Rental Amount for {customer_name}: ${total_rental_amount:.2f}")
            generate_and_save_rent_invoice(customer_name, rented_items, total_rental_amount)
            file_operations.write_equipment_data(equipment_data, "equipment.txt")  # Update the file with new equipment quantities

    except ValueError:
        print("Invalid input. Please enter valid values.")
