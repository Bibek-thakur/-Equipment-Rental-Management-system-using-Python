import datetime
import display_functions
import file_operations

# Function to generate and save return invoice
def generate_and_save_return_invoice(equipment, return_quantity, return_days, fine_amount, return_datetime):
    return_invoice = f"===== Return Invoice =====\nEquipment: {equipment['name']} ({equipment['brand']})\nReturned Quantity: {return_quantity}\nReturn Date: {return_datetime.strftime('%Y-%m-%d %H:%M:%S')}\nNumber of Days Rented: {return_days}\nFine Amount: ${fine_amount:.2f}"

    customer_name = input("Enter customer name: ").strip()
    return_invoice_filename = f"{customer_name}_return_invoice.txt"

    with open(return_invoice_filename, "w") as file:
        file.write(return_invoice)

    print(f"Return Invoice saved as '{return_invoice_filename}'")

# Function to return equipment
def return_equipment(equipment_data):
    try:
        while True:
            display_functions.display_available_equipment(equipment_data)  # Display available equipment
            equipment_index = int(input("Enter the equipment number to return: ")) - 1

            if 0 <= equipment_index < len(equipment_data):
                equipment = equipment_data[equipment_index]
                return_quantity = int(input(f"Enter returned quantity for {equipment['name']}: "))
                if return_quantity > 0:
                    equipment_data[equipment_index]["quantity"] += return_quantity

                    return_days = int(input("Enter the number of days the equipment was rented for: "))
                    fine_per_day = 10  # Fine amount per day (can be adjusted as needed)
                    max_allowed_days = 5  # Maximum allowed rental days without fine

                    if return_days > max_allowed_days:
                        extra_days = return_days - max_allowed_days
                        fine_amount = fine_per_day * extra_days
                    else:
                        fine_amount = 0

                    current_datetime = datetime.datetime.now()
                    generate_and_save_return_invoice(equipment, return_quantity, return_days, fine_amount, current_datetime)
                    print(f"Successfully returned {return_quantity} units of {equipment['name']}.")

                else:
                    print("Invalid return quantity. Please enter a valid positive value.")

            else:
                print("Invalid equipment number.")

            another_return = input("Do you want to return another item? (yes/no): ").lower()
            if another_return != "yes":
                break
    except ValueError:
        print("Invalid input. Please enter valid values.")
