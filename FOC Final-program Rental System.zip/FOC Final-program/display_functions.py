# Function to display available equipment
def display_available_equipment(equipment_data):
    print("*****************************************************************")
    print("-----------------------Available Equipments----------------------")
    print("*****************************************************************")
    for i, equipment in enumerate(equipment_data, start=1):
        print(
            f"{i}. {equipment['name']} ({equipment['brand']}) - ${equipment['price']} - Quantity: {equipment['quantity']}")
