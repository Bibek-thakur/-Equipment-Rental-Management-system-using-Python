import rental_functions
import return_functions
import display_functions
import file_operations
# Main program loop
def main():
    equipment_data = file_operations.read_equipment_data("equipment.txt")  # Loading equipment data from the file
    while True:
        print(
            "==========================================================================================================================================")
        print(
            "***************************************************Bibek's Rental Shop********************************************************************")
        print(
            "==========================================================================================================================================")
        print("1. Display Equipments")
        print("2. Rent Equipment")
        print("3. Return Equipment")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            display_functions.display_available_equipment(equipment_data)

        elif choice == "2":
            rental_functions.rent_equipment(equipment_data)
            file_operations.write_equipment_data(equipment_data,
                                                 "equipment.txt")  # Update the file with new equipment quantities

        elif choice == "3":
            return_functions.return_equipment(equipment_data)
            file_operations.write_equipment_data(equipment_data,
                                                 "equipment.txt")  # Update the file with new equipment quantities

        elif choice == "4":
            print("====================================")
            print("-----------Thank You!---------------")
            print("====================================")
            break
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()
