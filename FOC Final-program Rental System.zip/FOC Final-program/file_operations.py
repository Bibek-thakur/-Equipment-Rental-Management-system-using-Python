import os

# Function to write equipment data to the file
def write_equipment_data(equipment_data, filename):
    with open(filename, "w") as file:
        for equipment in equipment_data:
            file.write(f"{equipment['name']}, {equipment['brand']}, {equipment['price']}, {equipment['quantity']}\n")

# Function to read equipment data from the file
def read_equipment_data(filename):
    equipment_data = []
    if os.path.exists(filename):
        with open(filename, "r") as file:
            for line in file:
                name, brand, price, quantity = line.strip().split(", ")
                equipment_data.append({"name": name, "brand": brand, "price": float(price), "quantity": int(quantity)})
    return equipment_data
